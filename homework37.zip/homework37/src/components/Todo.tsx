import React from "react";
import { Card, CardContent,Typography, Container, IconButton } from '@mui/material';
import CheckIcon from '@mui/icons-material/Check';
import DeleteForeverIcon from '@mui/icons-material/DeleteForever';
type TodoProps = {
    title: string 
    checkTodo: object
    id: number 
    isCompleted: boolean 
    deleteTodo: void
}

const Todo = (props: TodoProps) => {
    const markComplete = () => props.checkTodo(props.id);
    const delTodo = () => props.deleteTodo(props.id)
    const todoStyle = props.isCompleted
        ? {textDecoration: "line-through"}
        : {textDecoration: "none"};
    console.log(props.isCompleted);
    
    return (
        <div>
            <Container>
                <Card variant="outlined" style={{marginTop: 35, background:"lightgray"}}>
                    <CardContent>
                        <Typography variant="h5" component="h2" style={todoStyle}>
                            <IconButton onClick={markComplete}>
                                <CheckIcon style={{color: "green"}}/>
                            </IconButton>
                            {props.title}
                            <IconButton onClick={delTodo} style={{float: "right"}}>
                                <DeleteForeverIcon style={{color: "red"}}/>
                            </IconButton>
                        </Typography>
                    </CardContent>

                </Card>
            </Container>
        </div>)
};
export default Todo;